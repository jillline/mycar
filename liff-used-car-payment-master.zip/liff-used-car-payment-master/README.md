# liff-used-car-payment
Used car payment calculator

## Demo
https://liff-used-car-payment.web.app/

## License
WTFPL 2.0 [http://www.wtfpl.net/](http://www.wtfpl.net/)
